import { styled, Stack } from '@mui/material';

export const Container = styled(Stack)`
    width: fit-content;
    border-radius: 8px;
    padding: 6px 8px;
`;
