import React from 'react';
import ProductPageHeader from 'src/components/ProductPageHeader';

const MyNFTSold: React.FC = (): JSX.Element => {
    return (
        <>
            <ProductPageHeader />
            MyNFTSold
        </>
    );
};

export default MyNFTSold;
