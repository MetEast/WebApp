export type AuthContextType = {
    isLoggedIn: boolean
};