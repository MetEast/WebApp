export type TypeNotification = {
    title: string;
    content: string;
    date: string;
    isRead?: boolean;
};
